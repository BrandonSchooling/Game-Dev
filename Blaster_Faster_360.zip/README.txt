This project was the result of my first work with Game Maker Studio 2.

I followed this course: https://www.udemy.com/be-a-game-maker-with-gamemaker-studio-2/

After completeing this course I decided to do a quick pass through to try and clean things up,
	little efficiencies and comments and stuff like that.